# Building Mage Potioneer for the browser (pygbag)

1. Put these .py files in your game folder, replacing the originals, next to your
   `assets/` and `map/` folders. The folder must look like:

       mage-potioneer/
         main.py  character.py  ingredient.py  map.py  progress.py
         main_collection.py  main_mixing.py
         assets/   map/

   (Leave out the `deprecated` folder and the readmes to keep the download small.)

2. From the folder ABOVE it:

       pip install pygbag
       pygbag mage-potioneer          # builds, then serves at http://localhost:8000
       pygbag --build mage-potioneer  # build only -> mage-potioneer/build/web.zip

3. Test at http://localhost:8000 in Chrome/Firefox (click the page once to start audio).

4. Publish: upload `build/web.zip` to itch.io (Kind of project: HTML, tick
   "This file will be played in the browser"), or push the contents of `build/web/`
   to GitHub Pages / Netlify.
